// Code snippet - 3

void f3() {
    int b;
    int c=5;
    if( a+b ) {
        b=2;
    }
    else {
        int b=6;
        int sum=b+c;
    }
}       
int main() {
    f3();
}