// Code snippet - 4

void f4() {
    int *q;
    int a = *q;
}       
int main() {
    f4();
}