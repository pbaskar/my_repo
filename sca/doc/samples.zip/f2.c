// Code snippet - 2

void f2() {
    int b;
    int c=5;
    int sum;
     if( a+b ) {
        b=2;
    }
    else {
        int sum=b+c;
    }
}
int main() {
    f2();
}