// Code snippet - 1

void f1() {
    int b;
    int c=5;
    int sum = b+c;
}
int main() {
    f1();
}